//
//  Dictionary+StringOutput.swift
//  MoltinAuth
//
//  Created by Andrei Nagy on 11/1/16.
//  Copyright © 2016 Andrei Nagy. All rights reserved.
//

import Foundation

extension Dictionary {
    
    /* Convenience function to provide http body
    */
    func encodedString() -> String {
        
        let string = self.map {
            if let key = $0 as? String,
                let value = $1 as? String {
                return "\(key.percentEscapedString())=\(value.percentEscapedString())"
            }
            return ""
            }
            .joined(separator: "&")
        
        return string
    }
}
