//
//  KeychainWrapper.swift
//  MoltinAuth
//
//  Created by Andrei Nagy on 11/1/16.
//  Copyright © 2016 Andrei Nagy. All rights reserved.
//

import UIKit

/* Sample keychain wrapper to store the access token in a secure way on iOS.
 */
class KeychainWrapper {

    static let standard = KeychainWrapper()
    fileprivate static let serviceName = "MoltinKeychainService"
    
    func set(value: String, key: String) -> Bool {
        if self.valueExists(key: key) {
            return self.update(value: value, key: key)
        } else {
            return self.create(value: value, key: key)
        }
    }
    
    func value(key: String) -> String? {
        guard let data = self.data(key: key) else {
            return nil
        }
        return String(data: data, encoding: String.Encoding.utf8)
    }
    
    func removeValue(key:String) -> Bool {
        return self.deleteValue(key: key)
    }
    
    func reset() -> Bool {
        let searchDictionary = self.basicDictionary()
        let status = SecItemDelete(searchDictionary as CFDictionary)
        return status == errSecSuccess
    }
    
    func valueExists(key: String) -> Bool {
        return self.data(key: key) != nil
    }
}

/* Private accessors
 */
extension KeychainWrapper {
    
    fileprivate func create(value: String, key: String) -> Bool {
        var dictionary = self.searchDictionary(key: key)
        
        dictionary[kSecValueData as String] = value.data(using: String.Encoding.utf8, allowLossyConversion: false) as AnyObject?
        
        let status = SecItemAdd(dictionary as CFDictionary, nil)
        return status == errSecSuccess
    }
    
    fileprivate func update(value: String, key: String) -> Bool {
        
        let searchDictionary = self.searchDictionary(key: key)
        var updateDictionary = [String: AnyObject]()
        
        updateDictionary[kSecValueData as String] = value.data(using: String.Encoding.utf8, allowLossyConversion: false) as AnyObject?
        
        let status = SecItemUpdate(searchDictionary as CFDictionary, updateDictionary as CFDictionary)
        
        return status == errSecSuccess
    }
    
    fileprivate func deleteValue(key: String) -> Bool {
        let searchDictionary = self.searchDictionary(key: key)
        let status = SecItemDelete(searchDictionary as CFDictionary)
        
        return status == errSecSuccess
    }
    
    fileprivate func data(key: String) -> Data?  {
        
        var searchDictionary = self.searchDictionary(key: key)
        
        searchDictionary[kSecMatchLimit as String] = kSecMatchLimitOne
        searchDictionary[kSecReturnData as String] = kCFBooleanTrue
        
        var retrievedData: AnyObject?
        let status = SecItemCopyMatching(searchDictionary as CFDictionary, &retrievedData)
        
        var data: Data?
        if status == errSecSuccess {
            data = retrievedData as? Data
        }
        
        return data
    }
    
    fileprivate func searchDictionary(key: String) -> [String: AnyObject] {
        let encodedIdentifier = key.data(using: String.Encoding.utf8, allowLossyConversion: false)
        
        var searchDictionary = self.basicDictionary()
        searchDictionary[kSecAttrGeneric as String] = encodedIdentifier as AnyObject?
        searchDictionary[kSecAttrAccount as String] = encodedIdentifier as AnyObject?
        
        return searchDictionary
    }
    
    fileprivate func basicDictionary() -> [String: AnyObject] {
        return [kSecClass as String : kSecClassGenericPassword, kSecAttrService as String : KeychainWrapper.serviceName as AnyObject]
    }
}
