//
//  String+PercentEscapeString.swift
//  MoltinAuth
//
//  Created by Andrei Nagy on 11/1/16.
//  Copyright © 2016 Andrei Nagy. All rights reserved.
//

import Foundation

extension String {
    
    /* Percent encode string for HTTP request
    */
    func percentEscapedString() -> String {
        var string = self
        string = string.addingPercentEncoding(withAllowedCharacters: .urlHostAllowed)!
        return string
    }
}
