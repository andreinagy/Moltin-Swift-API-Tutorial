//
//  Moltin.swift
//  MoltinAuth
//
//  Created by Andrei Nagy on 11/1/16.
//  Copyright © 2016 Andrei Nagy. All rights reserved.
//

import UIKit

/* Convenience for HTTP methods
 */
enum HTTPMethodType: String {
    case GET = "GET"
    case POST = "POST"
    case PUT = "PUT"
    case DELETE = "DELETE"
}

/* Access token types
 */
enum GrantType: String {
    case Implicit = "implicit"
    case ClientCredentials = "client_credentials"
    case RefreshToken = "refresh_token"
}

/* Auth parameter keys
 */
enum AuthParameter: String {
    case GrantType = "grant_type"
    case ClientId = "client_id"
    case ClientSecret = "client_secret"
    case RefreshToken = "refresh_token"
}

/* Moltin endpoints
 */
enum MoltinEndpoint: String {
    case Auth = "oauth/access_token"
    case Products = "v1/products"
}

class Moltin: NSObject {
    
    static let kMoltinAPIURLString = "https://api.molt.in/"
    
    static let shared = Moltin()
    
    let tokenStorage = MoltinTokenStorage()
    
    /* Auth call to obtain an access token.
     * On production apps, this should be called if there isn't any saved access token
    */
    func auth(clientId: String,
              clientSecret: String,
              completion: @escaping (_ errorMessage: String?) -> ()) {
        
        let dict = [
            AuthParameter.ClientId.rawValue: clientId,
            AuthParameter.ClientSecret.rawValue: clientSecret,
            AuthParameter.GrantType.rawValue: GrantType.ClientCredentials.rawValue,
            ]
        
        if let url = URL(string: Moltin.kMoltinAPIURLString + MoltinEndpoint.Auth.rawValue) {
            var request = URLRequest(url: url)
            request.httpMethod = HTTPMethodType.POST.rawValue
            
            request.httpBody = dict.encodedString().data(using: String.Encoding.utf8)
            
            let session = URLSession.shared
            
            let task = session.dataTask(with: request) {
                [weak self]
                (data, response, error) in
                print("Auth received response: \(response) \n error: \(error)")
                
                var errorMessage: String? = nil
                
                if let strongSelf = self {
                    
                    /* Try to extract the token from the response.
                    */
                    do {
                        try strongSelf.tokenStorage.update(data: data)
                    } catch {
                        errorMessage = error.localizedDescription
                    }
                    
                    /* Catch authentication errors.
                     */
                    errorMessage = strongSelf.tokenStorage.authErrorMessage(data: data)
                }
                completion(errorMessage)
            }
            
            task.resume()
        }
    }
    
    /* Refresh an existing token
    */
    func refreshToken() {
        print("refreshToken() not implemented")
    }
    
    func deleteToken() {
        self.tokenStorage.deleteToken()
    }
    
    func getProducts(completion: @escaping (_ errorMessage: String?, _ result: [String: AnyObject]?) -> ()) {
        
        let token = self.tokenStorage.accessToken ?? ""
        let dict = [
            "Authorization": "Bearer \(token)",
        ]
        
        if let url = URL(string: Moltin.kMoltinAPIURLString + MoltinEndpoint.Products.rawValue) {
            var request = URLRequest(url: url)
            request.httpMethod = HTTPMethodType.GET.rawValue
            
            for key in dict.keys {
                request.setValue(dict[key], forHTTPHeaderField: key)
            }
            
            let session = URLSession.shared
            
            let task = session.dataTask(with: request) {
                [weak self]
                (data, response, error) in
                print("Products received response: \(response) \n error: \(error)")
                
                var errorMessage: String? = nil
                var result: [String: AnyObject]? = nil
                
                if let strongSelf = self {
                    errorMessage = strongSelf.tokenStorage.authErrorMessage(data: data)
                }
                
                /* Intentionally allowing deserialization to see contents
                */
                do {
                    if let json = try JSONSerialization.jsonObject(with: data!) as? [String: AnyObject] {
                        result = json
                        
                    }
                } catch {
                    errorMessage = error.localizedDescription
                }
                completion(errorMessage, result)
            }
            
            task.resume()
        }
    }
}
