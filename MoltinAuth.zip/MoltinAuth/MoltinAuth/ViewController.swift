//
//  ViewController.swift
//  MoltinAuth
//
//  Created by Andrei Nagy on 11/1/16.
//  Copyright © 2016 Andrei Nagy. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    let kClientId = "your_client_id_here"
    let kClientSecret = "your_client_secret_here"
    
    @IBAction func auth(_ sender: Any) {
        Moltin.shared.auth(clientId: kClientId, clientSecret: kClientSecret) {
            [weak self]
            (errorMessage) in
            
            DispatchQueue.main.async {
                if let strongSelf = self {
                    strongSelf.showAlert(errorMessage: errorMessage,
                                         successString: "Authentication suceeded")
                }
            }
        }
    }
    
    @IBAction func badAuth(_ sender: Any) {
        Moltin.shared.auth(clientId: "wrongClientId", clientSecret: kClientSecret) {
            [weak self]
            (errorMessage) in
            
            DispatchQueue.main.async {
                if let strongSelf = self {
                    strongSelf.showAlert(errorMessage: errorMessage,
                                         successString: "Authentication suceeded")
                }
            }
        }
    }
    
    @IBAction func refreshToken(_ sender: Any) {
        
        Moltin.shared.refreshToken()
    }
    
    @IBAction func deleteToken(_ sender: Any) {
        Moltin.shared.deleteToken()
    }
    
    @IBAction func getProducts(_ sender: Any) {
        Moltin.shared.getProducts {
            [weak self]
            (errorMessage, dict) in
            
            DispatchQueue.main.async {
                if let strongSelf = self {
                    strongSelf.showAlert(errorMessage: errorMessage,
                                         successString: "Products list received")
                }
            }
        }
    }
    
    /* Helper to show the error message if exists or a preset success string.
     */
    func showAlert(errorMessage: String?, successString: String) {
        if let string = errorMessage {
            self.showAlert(title: "Error", message: string)
        } else {
            self.showAlert(title: "Success", message: successString)
        }
    }
    
    /* Show an UIAlertViewController
     */
    func showAlert(title: String, message: String) {
        let alert = UIAlertController(title: title, message: message, preferredStyle: .alert)
        let action = UIAlertAction(title: "OK", style: .default, handler: nil)
        alert.addAction(action)
        self.present(alert, animated: true)
    }
}

