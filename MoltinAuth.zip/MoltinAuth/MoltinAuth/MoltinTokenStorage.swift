//
//  MoltinTokenStorage.swift
//  MoltinAuth
//
//  Created by Andrei Nagy on 11/1/16.
//  Copyright © 2016 Andrei Nagy. All rights reserved.
//

import UIKit

/* Auth request response JSON keys
 */
enum AuthResponseKeys: String {
    case AccessToken = "access_token"
    case TokenType = "token_type"
    case Identifier = "identifier"
    case ExpiresEpochTime = "expires"
    case ExpiresInterval = "expires_in"
}

/* Any response to any call when the accessToken is not valid anymore
 */
enum TokenInvalidResponseKeys: String {
    case Status = "status"
    case Error = "error"
    case Errors = "errors"
}

class MoltinTokenStorage: NSObject {
    
    static let kAccessTokenKey = "access_token_key"
    
    let keychainWrapper = KeychainWrapper()
    
    /* Property only set through func update(data)
    */
    private(set) var accessToken: String? = nil {
        didSet {
            if let t = self.accessToken {
                let error = self.keychainWrapper.set(value: t, key: MoltinTokenStorage.kAccessTokenKey)
                print("saving access token: \(t)")
                if error {
                    print("error saving access token to the keychain")
                }
            } else {
                let error = self.keychainWrapper.removeValue(key: MoltinTokenStorage.kAccessTokenKey)
                if error {
                    print("error removing access token to the keychain")
                }
            }
        }
    }
    
    override init() {
        self.accessToken = self.keychainWrapper.value(key: MoltinTokenStorage.kAccessTokenKey)
    }
    
    func update(data: Data?) throws {
        if let d = data {
            do {
                if let json = try JSONSerialization.jsonObject(with: d) as? [String: AnyObject] {
                    if let t = json[AuthResponseKeys.AccessToken.rawValue] as? String {
                        self.accessToken = t
                    }
                }
            } catch {
                throw error
            }
        }
    }
    
    func deleteToken() {
        self.accessToken = nil
    }
    
    /* Return the Moltin error message if the token is expired.
     *  An empty message means that the token is valid.
    */
    func authErrorMessage(data: Data?) -> String? {
        var result: String? = nil
        if let d = data {
            do {
                if let json = try JSONSerialization.jsonObject(with: d) as? [String: AnyObject] {
                    if let bool = json[TokenInvalidResponseKeys.Status.rawValue] as? Bool {
                        if bool == false {
                            if let error = json[TokenInvalidResponseKeys.Error.rawValue] as? String {
                                result = error
                            } else if let error = json[TokenInvalidResponseKeys.Errors.rawValue] as? String {
                                result = error
                            } else {
                                result = "Unknown Error"
                            }
                        }
                    }
                }
            } catch {
                result = error.localizedDescription
            }
        }
        return result
    }
}
